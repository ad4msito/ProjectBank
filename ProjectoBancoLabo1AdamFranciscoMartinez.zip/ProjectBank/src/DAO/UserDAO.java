package DAO;

public interface UserDAO {

}
