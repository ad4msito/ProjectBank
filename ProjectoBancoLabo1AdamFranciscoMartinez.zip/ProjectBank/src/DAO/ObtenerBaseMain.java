package DAO;

public class ObtenerBaseMain {

        public static void main(String[] args) {
            System.out.println("Url:");
            System.out.println(DBManager.obtenerUbicacionBase());
        }
}

