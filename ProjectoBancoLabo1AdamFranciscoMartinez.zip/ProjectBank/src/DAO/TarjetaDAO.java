package DAO;

public interface TarjetaDAO {

}
