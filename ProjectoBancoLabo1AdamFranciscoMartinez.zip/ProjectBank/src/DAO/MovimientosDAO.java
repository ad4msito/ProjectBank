package DAO;

public interface MovimientosDAO {

}
