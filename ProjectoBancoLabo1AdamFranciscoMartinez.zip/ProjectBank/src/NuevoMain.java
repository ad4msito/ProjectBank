import GUI.CuentaGUI;
public class NuevoMain {
    public static void main(String[] args) {
        CuentaGUI a = new CuentaGUI();
        a.ventana();
        a.paneles();
        a.tabla();
        a.botones();
    }
}

