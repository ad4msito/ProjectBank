package Controlador.userType;

import Controlador.Usuario;

public class UserAdmin extends Usuario {

}
