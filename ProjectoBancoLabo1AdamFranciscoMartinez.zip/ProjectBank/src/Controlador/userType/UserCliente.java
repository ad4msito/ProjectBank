package Controlador.userType;

import Controlador.Usuario;

public class UserCliente extends Usuario {

}
